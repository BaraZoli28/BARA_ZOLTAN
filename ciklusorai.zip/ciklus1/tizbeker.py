eredmeny= 0
for x in range(10):
    a=int(input("Szám: "))
    if a <0:
        eredmeny+= a
print(eredmeny)
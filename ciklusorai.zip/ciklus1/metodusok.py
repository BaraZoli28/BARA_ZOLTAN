1#feladat

def feladat1():
    for i in range(-6):
        print(i)

def feladat2():
    for i in range(16,6):
        print(i)

def feladat3():
        for i in range(21):
            print(i)

def feladat4():
    for i in range(20,58,2):
        print(i,"",end=" ")

def feladat5():
    for i in range(77,-77,-2):
        print(i)

def feladat6():
        szam1=int(input("Adjon:"))
        szam2=int(input("Adjon számot:"))
        if szam1<szam2:
            for i in range(szam1,szam2+1):
                print(i)
        else:
            for i in range(szam2,szam1+1):
                print(i)


def feladat7():
    szam1 = int(input("Adjon:"))
    szam2 = int(input("Adjon számot:"))
    szam3=szam1*szam2
    if szam3>0:
        for i in range(0, szam3+1):
            print(i)
    elif szam3<0:
        for i in range(0, szam3 , -1):
            print(i)
    else:print("0")

def feladat9():
    for x in range(0,7):
        print(x, end=",")
    print(7)
def feladattizenegy():
    szam1=int(input("Adjon meg egy számot: "))
    szam2=int(input("Adjon meg egy másik számot: "))
    c=0
    for i in range(szam1,szam2+1):
        if i %2==0:
            c+=1
    print(c)
import metodusok
import tizenegyesfeladat
#metodusok.feladat4()
#metodusok.feladat5()
#metodusok.feladat6()
 #metodusok.feladat9()

#tizenegyesfeladat.feladattizenegy()
import feladat11b
feladat11b.feladat11b()

def tizenkettesfeladat:
    szam1=int(input("Első szám: "))
    szam2=int(input("Második szám: "))
    szam3=int(input("Harmadik szám: "))

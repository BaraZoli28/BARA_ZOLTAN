def feladat11b():
    szam1=int(input("Első szám: "))
    szam2=int(input("Második szám: "))
    paros = 0
    if szam1 < szam2:
        i=1
    else:
        i = -1
    if szam1 % 2 !=0:
        szam1 += i
    for _ in range (szam1, szam2 + i, i*2):
        paros += 1
    print(paros)